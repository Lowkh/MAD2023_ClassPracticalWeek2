package sg.edu.np.mad.week2pracclass;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    final String TAG ="Main Activity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ImageView imageNew = findViewById(R.id.imageView);
        imageNew.setImageResource(R.drawable.hi);
        Button buttonA = findViewById(R.id.button1);
        buttonA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.v(TAG, "ButtonA Pressed!");
            }
        });


    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.v(TAG, "Paused");
    }

    @Override
    protected void onStart(){
        super.onStart();
        Log.v(TAG, "Started");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.v(TAG, "Stopped!");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.v(TAG, "Destory!!");
    }


}